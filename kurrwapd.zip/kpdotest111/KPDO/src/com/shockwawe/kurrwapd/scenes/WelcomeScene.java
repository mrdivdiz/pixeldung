package com.shockwawe.kurrwapd.scenes;

import com.shockwawe.kurrwapd.Badges;
import com.shockwawe.kurrwapd.Chrome;
import com.shockwawe.kurrwapd.PixelDungeon;
import com.shockwawe.kurrwapd.Rankings;
import com.shockwawe.kurrwapd.ui.Archs;
import com.shockwawe.kurrwapd.ui.RedButton;
import com.shockwawe.kurrwapd.ui.ScrollPane;
import com.shockwawe.kurrwapd.ui.Window;
import com.shockwawe.noosa.BitmapTextMultiline;
import com.shockwawe.noosa.Camera;
import com.shockwawe.noosa.Game;
import com.shockwawe.noosa.NinePatch;
import com.shockwawe.noosa.ui.Component;

//TODO: update this class with relevant info as new versions come out.
public class WelcomeScene extends PixelScene {

	
	
	
	public static String Serverconn = " ";
	private static final String TTL_Welcome = "Look here!";

	private static final String TTL_Update = "  Version: 0.5.6REV2";

	private static final String TTL_Future = "Here's some changes and tips.";

	private static final String TXT_Welcome = "	Kurrwa Pixel Dungeon\n\n"
			+ Serverconn + "\n\n\n\n"
			+"This is a version of Pixel Dungeon from Watabou with blackjack & bitches.\n\n"
			+ "Included some of additions from Sprouted and Your versions.\n\n"
			+ "This version was adapted for those who love to grind, level up, and collect loot, like Sprouted.\n\n"
			+ "This version includes DJ S3RL's music.NOTE: that music won't included in source code and already in S3RL's FREE public mixes.\n\n"
			+"\n\n"

			+"Sprouted Pixel Dungeon differences:\n\n"
			+"Much larger levels (x16) creating a different game play and strategy experience.\n\n"
			+"Mobs drop monster meat to facilitate longer and more in-depth exploration of the larger levels.\n\n"
			//+"Dew system has been revised to create a currency for upgrade opportunities.\n\n"
			//+"Dew vial has been reworked as a new pivotal resource for exploring the dungeon.\n\n"
			//+"Wraiths and grave hunting is now a major part of the game progression.\n\n"
			+"Boss fights have been completely reworked to be more intense and challenging requiring completely new tactics.\n\n"
			+"Mobs now adjust strength as you go deeper in the dungeon to stay balanced with upgrades.\n\n"
			//+"New levels are accessible at each stage with Four additional levels available at the end of the game.\n\n"
			+"New levels include unique enemies, items and rewards.\n\n"
			+"\n\n"
			+"To unlock themes, get achivemens.\n\n"
			
			//+"New original items include:\n\n"
			//+"Nuts\n\n"
			//+"Four kinds of berries\n\n"
			//+"Mushrooms\n\n"
			//+"New potion type\n\n"
			//+"New scroll type\n\n"			
			//+"\n\n"
			
			//+"Hidden rarities include:\n\n"
			//+"Golden nut\n\n"
			//+"The Spork\n\n"
			//+"Full Moon Berry\n\n"
			//+"Honey\n\n"
			//+"\n\n"
			
			//+"New Mobs include:\n\n"
			//+"Rat Boss\n\n"
			//+"Shinobi\n\n"
			//+"Robots\n\n"
			//+"Liches\n\n"
			//+"Demon Goo\n\n"
			//+"\n\n"

			+"Many other tweaks and additions have been included!\n\n";


	private static final String TXT_Update = 
			"Version 0.5.6 adds Themes.\n\n"
			+"\n\n"	
			+"Sprouted Pixel Dungeon differences:\n\n"
			+"Much larger levels (x16) creating a different game play and strategy experience.\n\n"
			+"Mobs drop monster meat to facilitate longer and more in-depth exploration of the larger levels.\n\n"
			//+"Dew system has been revised to create a currency for upgrade opportunities.\n\n"
			//+"Dew vial has been reworked as a new pivotal resource for exploring the dungeon.\n\n"
			//+"Wraiths and grave hunting is now a major part of the game progression.\n\n"
			+"Boss fights have been completely reworked to be more intense and challenging requiring completely new tactics.\n\n"
			//+"Mobs now adjust strength as you go deeper in the dungeon to stay balanced with upgrades.\n\n"
		//	+"New levels are accessible at each stage with Four additional levels available at the end of the game.\n\n"
			//+"New levels include unique enemies, items and rewards.\n\n"
			+"\n\n"
			
			+"New original items include:\n\n"
			+"Beer, Pizza, Hamburger etc.\n\n"
			+"New weapons, mobs and common loot\n\n"
	        +"Themes changes view of UI & music\n\n"
	      //  +"New scroll type\n\n"
	      //  +"\n\n"
	        
		//	+"Hidden rarities include:\n\n"
			//+"Golden nut\n\n"
			//+"The Spork\n\n"
			//+"Full Moon Berry\n\n"
			//+"Honey\n\n"
			//+"\n\n"
	        
          //  +"New Mobs include:\n\n"
          //  +"Rat Boss\n\n"
          //  +"Shinobi\n\n"
          //  +"Robots\n\n"
           // +"Liches\n\n"
           // +"Demon Goo\n\n"
          //  +"\n\n"
            
		//	+"Many other tweaks and additions have been included!\n\n"
	
			;

	private static final String TXT_Future = "It seems that your current saves are from a future version of Kurrwa PD!\n\n"
			+ "Either you're messing around with older versions of the app, or something has gone buggy.\n\n"
			+ "Regardless, tread with caution! Your saves may contain things which don't exist in this version, "
			+ "this could cause some very weird errors to occur.";

	private static final String LNK = "https://play.google.com/store/apps/details?id=com.watabou.pixeldungeon";

	@Override
	public void create() {
		super.create();

		final int gameversion = 10;

		BitmapTextMultiline title;
		BitmapTextMultiline text;

		if (gameversion == 10) {

			text = createMultiline(TXT_Welcome, 8);
			title = createMultiline(TTL_Welcome, 16);

		

			text = createMultiline(TXT_Update, 6);
			title = createMultiline(TTL_Update, 9);

		} //else {

			//text = createMultiline(TXT_Future, 8);
			//title = createMultiline(TTL_Future, 16);

		//}

		int w = Camera.main.width;
		int h = Camera.main.height;

		int pw = w - 10;
		int ph = h - 50;

		title.maxWidth = pw;
		title.measure();
		title.hardlight(Window.TITLE_COLOR);

		title.x = align((w - title.width()) / 2);
		title.y = align(8);
		add(title);

		NinePatch panel = Chrome.get(Chrome.Type.WINDOW);
		panel.size(pw, ph);
		panel.x = (w - pw) / 2;
		panel.y = (h - ph) / 2;
		add(panel);

		ScrollPane list = new ScrollPane(new Component());
		add(list);
		list.setRect(panel.x + panel.marginLeft(), panel.y + panel.marginTop(),
				panel.innerWidth(), panel.innerHeight());
		list.scrollTo(0, 0);

		Component content = list.content();
		content.clear();

		text.maxWidth = (int) panel.innerWidth();
		text.measure();

		content.add(text);

		content.setSize(panel.innerWidth(), text.height());

		RedButton okay = new RedButton("Got it!") {
			@Override
			protected void onClick() {

				if (gameversion <= 32) {
					// removes all bags bought badge from pre-0.2.4 saves.
					Badges.disown(Badges.Badge.ALL_BAGS_BOUGHT);
					Badges.saveGlobal();

					// imports new ranking data for pre-0.2.3 saves.
					if (gameversion <= 29) {
						Rankings.INSTANCE.load();
						Rankings.INSTANCE.save();
					}
				}

				PixelDungeon.version( Game.version);
				Game.switchScene(TitleScene.class);
			}
		};

		/*
		 * okay.setRect(text.x, text.y + text.height() + 5, 55, 18); add(okay);
		 * 
		 * RedButton changes = new RedButton("Changes") {
		 * 
		 * @Override protected void onClick() { parent.add(new WndChanges()); }
		 * };
		 * 
		 * changes.setRect(text.x + 65, text.y + text.height() + 5, 55, 18);
		 * add(changes);
		 */

		okay.setRect((w - pw) / 2, h - 22, pw, 18);
		add(okay);

		Archs archs = new Archs();
		archs.setSize(Camera.main.width, Camera.main.height);
		addToBack(archs);

		fadeIn();
	}
}
