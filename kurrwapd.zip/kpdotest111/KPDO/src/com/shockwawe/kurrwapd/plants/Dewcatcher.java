/*
 * Pixel Dungeon
 * Copyright (C) 2012-2014  Oleg Dolya
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */
package com.shockwawe.kurrwapd.plants;

import com.shockwawe.kurrwapd.Assets;
import com.shockwawe.kurrwapd.Dungeon;
import com.shockwawe.kurrwapd.actors.Char;
import com.shockwawe.kurrwapd.actors.blobs.Blob;
import com.shockwawe.kurrwapd.actors.blobs.Fire;
import com.shockwawe.kurrwapd.actors.blobs.WaterOfTransmutation;
import com.shockwawe.kurrwapd.actors.blobs.WellWater;
import com.shockwawe.kurrwapd.actors.buffs.Buff;
import com.shockwawe.kurrwapd.actors.buffs.Slow;
import com.shockwawe.kurrwapd.actors.hero.Hero;
import com.shockwawe.kurrwapd.actors.mobs.Mob;
import com.shockwawe.kurrwapd.effects.CellEmitter;
import com.shockwawe.kurrwapd.effects.particles.FlameParticle;
import com.shockwawe.kurrwapd.items.Dewdrop;
import com.shockwawe.kurrwapd.items.RedDewdrop;
import com.shockwawe.kurrwapd.items.potions.PotionOfHealing;
import com.shockwawe.kurrwapd.items.potions.PotionOfLiquidFlame;
import com.shockwawe.kurrwapd.items.potions.PotionOfMight;
import com.shockwawe.kurrwapd.items.potions.PotionOfStrength;
import com.shockwawe.kurrwapd.levels.Level;
import com.shockwawe.kurrwapd.levels.Terrain;
import com.shockwawe.kurrwapd.plants.Plant.Seed;
import com.shockwawe.kurrwapd.scenes.GameScene;
import com.shockwawe.kurrwapd.sprites.ItemSpriteSheet;
import com.shockwawe.noosa.audio.Sample;
import com.shockwawe.utils.Random;

public class Dewcatcher extends Plant {

	private static final String TXT_DESC = "Grown from sparkling crystal seeds, Dewcatchers camouflage as grass to avoid attention, " +
			                                "but their bulges of collected dew give them away. " +
			                                "Shake them to harvest dew from their leaves. ";
	{
		image = 8;
		plantName = "Dewcatcher";
	}

	@Override
	public void activate(Char ch) {
		explodeDew(pos);
		if (Random.Int(2)==0){super.activate(ch);}	
		    
		
	}

	@Override
	public String desc() {
		return TXT_DESC;
	}

	public static class Seed extends Plant.Seed {
		{
			plantName = "Dewcatcher";

			name = "seed of " + plantName;
			image = ItemSpriteSheet.SEED_DEWCATCHER;

			plantClass = Dewcatcher.class;
			alchemyClass = PotionOfHealing.class;				
		}

		@Override
		public String desc() {
			return TXT_DESC;
		}
		
		
	}
	
public void explodeDew(int cell) {
		
		 for (int n : Level.NEIGHBOURS8) {
			 int c = cell + n;
			 if (c >= 0 && c < Level.LENGTH() && Level.passable[c]) {
				 
				if (Random.Int(10)==1){Dungeon.level.drop(new RedDewdrop(), c).sprite.drop();}		
			    else if (Random.Int(5)==1){Dungeon.level.drop(new Dewdrop(), c).sprite.drop();}
				else if (Random.Int(3)==1){Dungeon.level.drop(new Dewdrop(), c).sprite.drop();}
				else if (Random.Int(7)==1){Dungeon.level.drop(new RedDewdrop(), c).sprite.drop();}
			}
		  }	
		
	}


		
	
}
