/*
 * Pixel Dungeon
 * Copyright (C) 2012-2015 Oleg Dolya
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */
package com.shockwawe.kurrwapd.items.govno;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.shockwawe.kurrwapd.Assets;
import com.shockwawe.kurrwapd.Badges;
import com.shockwawe.kurrwapd.Dungeon;
import com.shockwawe.kurrwapd.actors.Actor;
import com.shockwawe.kurrwapd.actors.Char;
import com.shockwawe.kurrwapd.actors.buffs.SnipersMark;
import com.shockwawe.kurrwapd.actors.hero.Hero;
import com.shockwawe.kurrwapd.effects.Degradation;
import com.shockwawe.kurrwapd.effects.Speck;
import com.shockwawe.kurrwapd.items.Item;
import com.shockwawe.kurrwapd.items.armor.Armor;
import com.shockwawe.kurrwapd.items.bags.Bag;
import com.shockwawe.kurrwapd.items.rings.Ring;
import com.shockwawe.kurrwapd.items.wands.Wand;
import com.shockwawe.kurrwapd.items.weapon.Weapon;
import com.shockwawe.kurrwapd.items.weapon.missiles.MissileWeapon;
import com.shockwawe.kurrwapd.mechanics.Ballistica;
import com.shockwawe.kurrwapd.scenes.CellSelector;
import com.shockwawe.kurrwapd.scenes.GameScene;
import com.shockwawe.kurrwapd.sprites.CharSprite;
import com.shockwawe.kurrwapd.sprites.ItemSprite;
import com.shockwawe.kurrwapd.sprites.MissileSprite;
import com.shockwawe.kurrwapd.ui.QuickSlot;
import com.shockwawe.kurrwapd.utils.GLog;
import com.shockwawe.kurrwapd.utils.Utils;
import com.shockwawe.noosa.audio.Sample;
import com.shockwawe.utils.Bundlable;
import com.shockwawe.utils.Bundle;
import com.shockwawe.utils.Callback;
import com.shockwawe.utils.PointF;

public class Trash extends Item {
	
	String AC_LOOK = "CRAFT";
	public Hero hero;
	
	
}
