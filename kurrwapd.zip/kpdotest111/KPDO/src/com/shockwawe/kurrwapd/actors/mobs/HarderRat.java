/*
 * Pixel Dungeon
 * Copyright (C) 2012-2015 Oleg Dolya
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */
package com.shockwawe.kurrwapd.actors.mobs;

import com.shockwawe.kurrwapd.Dungeon;
import com.shockwawe.kurrwapd.actors.Char;
import com.shockwawe.kurrwapd.actors.mobs.npcs.Ghost;
import com.shockwawe.kurrwapd.items.Gold;
import com.shockwawe.kurrwapd.items.food.Burger;
import com.shockwawe.kurrwapd.items.food.ChargrilledMeat;
import com.shockwawe.kurrwapd.items.food.FrozenCarpaccio;
import com.shockwawe.kurrwapd.items.food.MysteryMeat;
import com.shockwawe.kurrwapd.items.potions.PotionOfHealing;
import com.shockwawe.kurrwapd.sprites.HarderRatSprite;
import com.shockwawe.utils.Random;

public class HarderRat extends Mob {

	{
		name = "Harder rat"; Dungeon.depth = 2;
		spriteClass = HarderRatSprite.class;
		
		HP = HT = 65;
		defenseSkill = 5;
		
		
		maxLvl = 5;
		
		loot = new PotionOfHealing();
		lootChance = 0.800f;
		
		loot = new Burger();
		lootChance = 1.500f;
		
		loot = new MysteryMeat();
		lootChance = 3.500f;
		
		loot = new FrozenCarpaccio();
		lootChance = 0.500f;
		
		loot = new Gold(Random.NormalIntRange(50, 250));
		
	}
	
	@Override
	public int damageRoll() {
		return Random.NormalIntRange( 1, 5 );
	}
	
	@Override
	public int attackSkill( Char target ) {
		return 2;
	}
	
	@Override
	public int dr() {
		return 1;
	}
	
	@Override
	public void die( Object cause ) {
		Ghost.Quest.processSewersKill( pos );
		
		super.die( cause );
	}
	
	@Override
	public String description() {
		return
			"Thats a harder rat.Try harder! " +
			"Try to kill me, motherfucka!";
	}
}
